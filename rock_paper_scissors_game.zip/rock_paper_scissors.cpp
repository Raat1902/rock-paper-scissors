
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    srand(time(0));

    vector<string> options = {"rock", "paper", "scissors"};
    int playerScore = 0;
    int computerScore = 0;
    int gamesPlayed = 0;
    string wordChosen;
    int menuChoice;

    cout << "Welcome to Rock, Paper, Scissors!" << endl;

    while (true) {
        cout << "\nMenu:\n1 = Play\n2 = Quit\nEnter your choice: ";
        cin >> menuChoice;

        if (menuChoice == 2) {
            cout << "\nThanks for playing!" << endl;
            break;
        } else if (menuChoice != 1) {
            cout << "Invalid choice. Try again." << endl;
            continue;
        }

        cout << "\nEnter your pick (rock, paper, or scissors): ";
        cin >> wordChosen;
        transform(wordChosen.begin(), wordChosen.end(), wordChosen.begin(), ::tolower);

        if (find(options.begin(), options.end(), wordChosen) == options.end()) {
            cout << "Invalid input. Please enter rock, paper, or scissors." << endl;
            continue;
        }

        string computerPick = options[rand() % options.size()];
        cout << "Computer picked: " << computerPick << endl;

        if (wordChosen == computerPick) {
            cout << "It's a tie!" << endl;
        } else if (
            (wordChosen == "rock" && computerPick == "scissors") ||
            (wordChosen == "paper" && computerPick == "rock") ||
            (wordChosen == "scissors" && computerPick == "paper")
        ) {
            cout << "You win this round!" << endl;
            playerScore++;
        } else {
            cout << "Computer wins this round!" << endl;
            computerScore++;
        }

        gamesPlayed++;
        cout << "------------------------" << endl;
        cout << "Your Score: " << playerScore << endl;
        cout << "Computer Score: " << computerScore << endl;
        cout << "Games Played: " << gamesPlayed << endl;
        float winRate = (playerScore * 100.0f) / gamesPlayed;
        cout << "Your Win Rate: " << winRate << "%" << endl;
        cout << "------------------------" << endl;
    }

    return 0;
}
