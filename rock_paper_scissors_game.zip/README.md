
# Rock, Paper, Scissors (C++ Terminal Game)

A simple terminal-based implementation of the classic Rock, Paper, Scissors game using C++.

## Features
- User plays against a computer opponent
- Randomized computer choices
- Score tracking for both player and computer
- Tracks number of games played
- Calculates player win rate after each round
- Input validation with graceful error handling
- Play as many rounds as you like, quit anytime

## How to Run
1. Compile the file:
   ```bash
   g++ -o rps rock_paper_scissors.cpp
   ```

2. Run the executable:
   ```bash
   ./rps
   ```

## Ideal For
- C++ beginners practicing input/output, conditionals, loops, and vectors
- Small terminal projects to showcase on GitHub

## License
MIT
